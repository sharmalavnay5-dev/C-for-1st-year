// WAP TO PRINT HELLO SHOOLINI ....
#include<stdio.h>
int main ()
{
    printf("Hello Shoolini");
    return 0;
}
