//Print Numbers from 1 to N Using Recursion

#include <stdio.h>

void printUp(int n) {
    if (n == 0) return;
    printUp(n - 1);
    printf("%d ", n);
}

int main() {
    int n;
    scanf("%d", &n);
    printUp(n);
    return 0;
}
