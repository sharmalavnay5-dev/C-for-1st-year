// WAP TO PRINT THE SUM OF 30% OF C MARKS AND 70%OF GEN AI MARKS 
#include<stdio.h>
int main()
{
    float C_marks, GenAI_marks, sum;
    printf("Enter marks of subjects\n");
    scanf("%f %f", &C_marks, &GenAI_marks);
sum = ((float)30.0/100.0)*C_marks + ((float)70.0/100.0)*GenAI_marks;
printf("The sum 30 OF C %f and 70 OF GEN AI MARKS:%f = %f", C_marks, GenAI_marks, sum);
}
