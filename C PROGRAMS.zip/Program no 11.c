// WAP TO INPUT A NUMBER FROM 1-7 AND PRINT THE CORRESPONDING DAY BY USING IF-ELSE-ELSE IF STATEMENTS:: 
#include<stdio.h>
int main()
{
    int day;
    printf("Enter the value of day(1-7)");
    scanf("%d", &day);
    if(day==1){
    printf("Monday");}
    else if(day==2){
        printf("Tuesday");
    }
    else if(day==3) {
        printf("Wednesday");
    }
    else if(day==4){
        printf("Thursday");
    }
    else if(day==5){
        printf("Friday");
    }
    else if(day==6){
        printf("Saturday");
    }
    else if(day==7){
        printf("Sunday");
    }
    return 0;
}