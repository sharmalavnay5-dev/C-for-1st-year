//Program to allocate memory and store n integers (using malloc)
#include <stdio.h>
#include <stdlib.h>

int main() {
    int n, *ptr;
    printf("Enter number of elements: ");
    scanf("%d", &n);

    ptr = (int *)malloc(n * sizeof(int));

    printf("Enter elements:\n");
    for(int i = 0; i < n; i++)
        scanf("%d", &ptr[i]);

    printf("You entered:\n");
    for(int i = 0; i < n; i++)
        printf("%d ", ptr[i]);

    free(ptr);
    return 0;
}
