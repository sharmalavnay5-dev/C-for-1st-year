#include <stdio.h>
int main()
{
    int j = 1;
    for(int i=1; i<=2; i++)
    {
        printf("Shoolini ");
        for( ; j<=2; j++)
        {
            printf("B.Tech CSE");
            for(int k=1; k<=2; k++)
            {
                printf("C program");
            }
        }
    }
    return 0;
}