//Function to Convert Celsius to Fahrenheit
#include <stdio.h>

float cToF(float c) {
    return (c * 9/5) + 32;
}

int main() {
    float c;
    printf("Enter Celsius: ");
    scanf("%f", &c);

    printf("Fahrenheit = %.2f\n", cToF(c));
    return 0;
}
