// WAP TO MAKE A Structure for Student Details
#include <stdio.h>

struct Student {
    int roll;
    char name[20];
};

int main() {
    struct Student s = {1, "Amit"};
    printf("Roll: %d\nName: %s", s.roll, s.name);
    return 0;
}
