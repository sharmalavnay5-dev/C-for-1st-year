// print the haft of the given range
#include <stdio.h>
int main(){
    int spoint,a,epoint,even;
    printf("enter the staritng point:");
    scanf("%d",&spoint);
    printf("enter the epoint: ");
    scanf("%d",&epoint);
    a= epoint+spoint;
    a=a/2;
    while(spoint<=a){
          
            printf("even number %d\n",spoint);
            spoint++;
        } 
        
    
    return 0;
}