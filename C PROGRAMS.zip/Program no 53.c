//WAP TO REVERSE A STRING AND CHECK IF IT IS PALLIDROME OR NOT


#include <stdio.h>
#include <string.h>

int main() {
    char str[100], rev[100];
    int i, len;

    printf("Enter a string: ");
    fgets(str, sizeof(str), stdin);

    // Remove newline fif present
    str[strcspn(str, "\n")] = '\0'; 

    len = strlen(str);

    // Reverse the string
    for (i = 0; i < len; i++) {
        rev[i] = str[len - 1 - i];
    }
    rev[len] = '\0';

    // Check palindrome
    if (strcmp(str, rev) == 0)
        printf("String is palindrome\n");
    else
        printf("String is not palindrome\n");

    printf("Reversed string: %s\n", rev);

    return 0;
}
