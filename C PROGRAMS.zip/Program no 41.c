//Write a C program that takes an integer from the user and counts how many digits the number contains using a separate function countdigit(). Handle negative numbers and zero correctly.
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

// Function to count digits
int countdigit(int num)
{
    int absnum = abs(num);                 // make number positive
    if (absnum == 0)
        return 1;                          // special case for 0

    int digitcount = (int)log10(absnum) + 1;
    return digitcount;
}

int main()
{
    int number;
    printf("Enter a number: ");
    scanf("%d", &number);

    printf("Number of digits in %d is: %d\n", number, countdigit(number));

    return 0;
}
