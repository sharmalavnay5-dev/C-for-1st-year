// WAP TO RPINT THE GIVEN PATTERN
//1
//22
//333
#include <stdio.h>
int main()
{
  int row, i, j;
  row = 3;
  for(i=1; i<=row; i++)
  {
    for(j=1; j<=i; j++)
    {
        printf("%d", i);
    }
    printf("\n");
  }  
  return 0;
}