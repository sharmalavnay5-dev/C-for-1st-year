//Structure Input From User
#include <stdio.h>

struct Book {
    char title[30];
    int price;
};

int main() {
    struct Book b;
    printf("Enter title and price: ");
    scanf("%s %d", b.title, &b.price);
    
    printf("Book: %s\nPrice: %d", b.title, b.price);
    return 0;
}
