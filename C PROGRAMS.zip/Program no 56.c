//Simple program to store a string using malloc
#include <stdio.h>
#include <stdlib.h>

int main() {
    char *name;
    int size;

    printf("Enter size of string: ");
    scanf("%d", &size);

    name = (char *)malloc(size * sizeof(char));

    printf("Enter your name: ");
    scanf("%s", name);

    printf("Hello, %s!", name);

    free(name);
    return 0;
}
