// Program to increase size using 
#include <stdio.h>
#include <stdlib.h>

int main() {
    int *p, n = 3;

    p = (int *)malloc(n * sizeof(int));
    printf("Enter 3 numbers: ");
    for(int i = 0; i < n; i++)
        scanf("%d", &p[i]);

    n = 5;
    p = (int *)realloc(p, n * sizeof(int));

    printf("Enter 2 more numbers: ");
    for(int i = 3; i < n; i++)
        scanf("%d", &p[i]);

    printf("Final array:\n");
    for(int i = 0; i < n; i++)
        printf("%d ", p[i]);

    free(p);
    return 0;
}
