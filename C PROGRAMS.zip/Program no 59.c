//Create a structure to store student details using typedef, take input from the user, and display the details
#include <stdio.h>

// creating a short name Student for struct student
typedef struct {
    int roll;
    char name[50];
    float marks;
} Student;

int main() {
    Student s;   // using typedef name directly

    printf("Enter roll number: ");
    scanf("%d", &s.roll);

    printf("Enter name: ");
    scanf("%s", s.name);

    printf("Enter marks: ");
    scanf("%f", &s.marks);

    printf("\n--- Student Details ---\n");
    printf("Roll Number: %d\n", s.roll);
    printf("Name: %s\n", s.name);
    printf("Marks: %.2f\n", s.marks);

    return 0;
}
