// WAP TO CHECK THE NO IS EVEN OR NOT 
#include<stdio.h>
int main()
{
    int num;
    printf("Enter the value of num:");
    scanf("%d",&num);
    if(num %2 == 0)
    {
        printf("%d is even number", num);
}
return 0;
}