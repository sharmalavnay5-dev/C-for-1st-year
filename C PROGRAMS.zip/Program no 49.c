//wap to print the length of string by inbuilt and without inbuilt

// with inbuilt

#include <stdio.h>
#include <string.h>
int main() {
    char s[100];
    printf("Enter a string: ");
    fgets(s, sizeof(s), stdin);
    int n = strlen(s);
    printf("Length of the string is: %d\n", n-1);
    return 0;
}
///////////////////////////////////////////////////////////

//without inbuilt

#include <stdio.h>
#include <string.h>

int main(){
    
    char s[100];
    int n,i,count;
    printf("Enter a string: ");
    fgets(s, sizeof(s), stdin);
    for(i=0;s[i]!='\0';i++){
        count++;
    }
    printf("The size of string :%d",count-1);
    return 0;
}