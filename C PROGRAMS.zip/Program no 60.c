//"Write a C program to store and display the ID and salary of 3 employees using structures."

#include <stdio.h>

struct Employee {
    int id;
    float salary;
};

int main() {
    struct Employee e[3];
    for(int i = 0; i < 3; i++) {
        printf("Enter id and salary: ");
        scanf("%d %f", &e[i].id, &e[i].salary);
    }

    for(int i = 0; i < 3; i++) {
        printf("ID: %d  Salary: %.2f\n", e[i].id, e[i].salary);
    }

    return 0;
}
